<?php

/* 
 * @package Engazz Project .
 * @Engazz Web Solution .
 * @http://engazz.com 
 * @Developed by : engazz team .
 * @Developer Site: http//engazz.com 
 */

defined('DB_SERVER') ? null : define("DB_SERVER", "localhost");
defined('DB_NAME')   ? null : define("DB_NAME", "eltamayo_eltamayo");
defined('DB_USER')   ? null : define("DB_USER", "eltamayo_eltamay");
defined('DB_PASS')   ? null : define("DB_PASS", "#}+u@ezb-aPK");
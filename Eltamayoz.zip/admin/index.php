<?php
/*
 * @Developed by : Ahmed Mosa .
 * @Developer Site: http//www.elmosamem.com 
 */
require_once '../init.php';

// Required Files .....
require_once PATH_BASE.DS.'config.php';
require_once ADMIN_PATH.DS.'core/session.php';
require_once ADMIN_PATH.DS.'core/app.php';
require_once ADMIN_PATH.DS.'core/controller.php';
require_once ADMIN_PATH.DS.'core/model.php';
require_once ADMIN_PATH.DS.'core/view.php';


$app = new App;
